package com.example.bluetoothapp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelUuid;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.ClipData.Item;
import android.util.Log;
import android.view.*;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQUEST_ENABLE_BT = 1;
    //private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
    private static final UUID MY_UUID= UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");
    //private static final UUID MY_UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");
    public BluetoothAdapter mBluetoothAdapter;
    
  
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            // Device does not support Bluetooth
            Context context = getApplicationContext();
            CharSequence text = "Device does not support bluetooth";
            int duration = Toast.LENGTH_LONG;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
            
        }
        else
        {
            Context context = getApplicationContext();
            CharSequence text = "Device supports bluetooth";
            int duration = Toast.LENGTH_LONG;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
            if (!mBluetoothAdapter.isEnabled()) 
            {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
            else
            {
                searchForDevices();
            }
            
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Check which request we're responding to
        if (requestCode == REQUEST_ENABLE_BT) {
            // Make sure the request was successful
            if (resultCode == RESULT_OK) {
                // The user picked a contact.
                // The Intent's data Uri identifies which contact was selected.
                Context context = getApplicationContext();
                CharSequence text = "Bluetooth is enabled";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                // Do something with the contact here (bigger example below)
                searchForDevices();
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    public void searchForDevices()
    {
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if (pairedDevices.isEmpty()) 
        {
            Context context = getApplicationContext();
            CharSequence text = "No paired devices";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();    
        } 
        else 
        {
            final ListView view = new ListView(this);
            view.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
            ArrayAdapter<BluetoothDevice> adapter =
                    new ArrayAdapter<BluetoothDevice>(this, R.layout.devicesavailabletextview, pairedDevices.toArray(new BluetoothDevice[pairedDevices.size()]))
                    {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    TextView view = (TextView) super.getView(position, convertView, parent);
                    BluetoothDevice bluetoothDevice = (BluetoothDevice) getItem(position);
                    view.setText(bluetoothDevice.getName() + " : " + bluetoothDevice.getAddress());
                    return view;
                }
            };
            view.setAdapter(adapter);
            view.setOnItemClickListener(new OnItemClickListener() {

     
        @Override
        public void onItemClick(AdapterView<?> arg0, View arg1, int position,
                long arg3) {
            // TODO Auto-generated method stub
            Context context = getApplicationContext();
            CharSequence text = "Position of device in list is : "+ position + "Address of device is : "+((BluetoothDevice) view.getItemAtPosition(position)).getAddress().toString();
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
            
            BluetoothDevice remoteDevice=mBluetoothAdapter.getRemoteDevice(((BluetoothDevice) view.getItemAtPosition(position)).getAddress().toString());
            //BluetoothDevice remoteDevice=mBluetoothAdapter.getRemoteDevice("38:E7:D8:2A:8F:BF");
            
                
            
            ConnectThread conThread=new ConnectThread(remoteDevice);
            conThread.start();
            //connectToDevice((BluetoothDevice) view.getItemAtPosition(position));
            
        }

//        
//        private void connectToDevice(BluetoothDevice itemAtPosition) {
//            // TODO Auto-generated method stub
//            BluetoothDevice remoteDevice=mBluetoothAdapter.getRemoteDevice(itemAtPosition.getAddress().toString());
//            UUID ftpUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
//            BluetoothSocket clientSocket;
//             BluetoothSocket mmSocket;
//             BluetoothDevice mmDevice;
//            // Use a temporary object that is later assigned to mmSocket,
//            // because mmSocket is final
//            BluetoothSocket tmp = null;
//     
//            // Get a BluetoothSocket to connect with the given BluetoothDevice
//            try {
//                // MY_UUID is the app's UUID string, also used by the server code
//                tmp = remoteDevice.createRfcommSocketToServiceRecord(ftpUID);
//            } catch (IOException e) { }
//            mmSocket = tmp;
//
//            
//            ParcelUuid[] uuids = remoteDevice.getUuids();
//            boolean isFileTransferSupported = false;
//            
//            // Check if remote device supports file transfer
//            for (ParcelUuid parcelUuid: uuids) {
//                if (parcelUuid.getUuid().equals(ftpUID)) {
//                    isFileTransferSupported = true;
//                    break;
//                }
//            }
//            if (!isFileTransferSupported) {
//                Context context = getApplicationContext();
//                CharSequence text = "File transfer is NOT supported";
//                int duration = Toast.LENGTH_LONG;
//                Toast toast = Toast.makeText(context, text, duration);
//                toast.show();
//            }
//            else
//            {
//                Context context = getApplicationContext();
//                CharSequence text = "File transfer is supported";
//                int duration = Toast.LENGTH_LONG;
//                Toast toast = Toast.makeText(context, text, duration);
//                toast.show();
//                
//                return;
//            }
//            
//        }
    });

            Dialog dialog = new Dialog(this);
            dialog.setContentView(view);
            dialog.setCancelable(true);
            dialog.show();
        }
            
    }
    
    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;
      
        public ConnectThread(BluetoothDevice device) {
            // Use a temporary object that is later assigned to mmSocket,
            // because mmSocket is final
            BluetoothSocket tmp = null;
            mmDevice = device;
     
            // Get a BluetoothSocket to connect with the given BluetoothDevice
            try {
                Log.d("Bluetooth","Inside constructor");
                // MY_UUID is the app's UUID string, also used by the server code
                tmp = device.
                		createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) {
                Log.e("Bluetooth","Inside constructor : Exception occured");
            }
            mmSocket = tmp;
        }
     
        public void run() 
        {
            Log.d("Bluetooth","Inside run method of connect thread");
            // Cancel discovery because it will slow down the connection
            mBluetoothAdapter.cancelDiscovery();
     
            try 
            {
                // Connect the device through the socket. This will block
                // until it succeeds or throws an exception
                Log.d("Bluetooth", "Inside try to connect");
                mmSocket.connect();
            } 
            catch (IOException connectException) 
            {
                // Unable to connect; close the socket and get out
                Log.e("Bluetooth", "exception");
                try
                {
                    mmSocket.close();
                }
                catch (IOException closeException) 
                { 
                }
                return;
            }
     
            Log.d("Bluetooth", "Successfully connected");
            // Do work to manage the connection (in a separate thread)
            manageConnectedSocket(mmSocket);            
        }
     
        public void manageConnectedSocket(BluetoothSocket mmSocket2) 
        {
			// TODO Auto-generated method stub
        	ConnectedThread connectedThread = new ConnectedThread(mmSocket2);
        	connectedThread.start();
		}

        private class ConnectedThread extends Thread {
            private final BluetoothSocket mmSocket;
            private final InputStream mmInStream;
            private final OutputStream mmOutStream;
         
            public ConnectedThread(BluetoothSocket socket) 
            {
                mmSocket = socket;
                InputStream tmpIn = null;
                OutputStream tmpOut = null;
         
                // Get the input and output streams, using temp objects because
                // member streams are final
                try 
                {
                    tmpIn = socket.getInputStream();
                    tmpOut = socket.getOutputStream();
                }
                catch (IOException e) 
                { 
                	
                }
                Log.d("Bluetooth","Inside constructor ConnectedThread : Successfully got socket input output stream");         
                mmInStream = tmpIn;
                mmOutStream = tmpOut;
            }
         
            public void run() 
            {
                byte[] buffer = new byte[1024];  // buffer store for the stream
                int bytes; // bytes returned from read()
         
                //Try and send data to remote device
                
                FileInputStream fileInputStream = null;

                //String name="Anshika";
                //buffer=name.getBytes();
                try
                {
                	Log.d("Bluetooth","Trying to send data to server");
                	//bufferedInputStream=new BufferedInputStream(new FileInputStream(new File(Environment.getExternalStorageDirectory()+"/downloaded_file.mp3")));
                	fileInputStream=new FileInputStream(new File(Environment.getExternalStorageDirectory()+"/downloaded_file.mp3"));
                    int readData=0,totalBytes=0;
                    while((readData=fileInputStream.read(buffer))!=-1)
                    {
                    	Log.d("Bluetooth","No of bytes read "+readData);
                    	mmOutStream.write(buffer);
                    	mmOutStream.flush();
                    	totalBytes+=readData;
                    	//Log.e("Bluetooth","Successfuly wrote the bytes");
                    }

                    Log.d("Bluetooth","Total Bytes Read "+totalBytes);
                    Log.d("Bluetooth","readData : "+readData);
    				Log.d("Bluetooth","Successfuly sent data to server");
    				//mmOutStream.close();
    				//mmSocket.close();
    			}
                catch (IOException e) 
                {
    				// TODO Auto-generated catch block
    				Log.e("Bluetooth","Problem to send data to server");
    				e.printStackTrace();
    			}
            }
         
            /* Call this from the main activity to send data to the remote device */
            public void write(byte[] bytes) {
                try {
                    mmOutStream.write(bytes);
                } catch (IOException e) { }
            }
         
            /* Call this from the main activity to shutdown the connection */
            public void cancel() {
                try {
                    mmSocket.close();
                } catch (IOException e) { }
            }
        }
        
		/** Will cancel an in-progress connection, and close the socket */
        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) { }
        }
    }

}